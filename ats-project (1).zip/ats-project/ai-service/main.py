from fastapi import FastAPI
from pydantic import BaseModel, Field
import re

app = FastAPI(title='ATS Text Processing Microservice', version='1.0.0')

class AnalyzeRequest(BaseModel):
    resume_text: str = Field(min_length=1, max_length=100000)
    job_description: str = Field(min_length=1, max_length=30000)
    required_skills: list[str] = []

SKILLS = ['javascript','typescript','react','node.js','express','mongodb','sql','python','java','html','css','rest api','git','aws','docker','machine learning','data analysis','pandas','numpy','communication','testing','jest','redux','material ui','fastapi']

def detect(text: str, extra: list[str]) -> list[str]:
    text = text.lower()
    result = []
    for skill in dict.fromkeys(SKILLS + extra):
        if re.search(r'(?<![a-z0-9+#.])' + re.escape(skill.lower()) + r'(?![a-z0-9+#.])', text):
            result.append(skill)
    return result

@app.get('/health')
def health():
    return {'status': 'ok', 'service': 'ats-ai-service'}

@app.post('/analyze')
def analyze(body: AnalyzeRequest):
    resume_skills = detect(body.resume_text, body.required_skills)
    required = detect(body.job_description, body.required_skills)
    required = list(dict.fromkeys(required + body.required_skills))
    matched = [s for s in required if s.lower() in {x.lower() for x in resume_skills}]
    missing = [s for s in required if s not in matched]
    score = round(len(matched) / len(required) * 100) if required else 0
    return {'extractedSkills': resume_skills, 'matchedSkills': matched, 'missingSkills': missing,
            'matchScore': score,
            'explanation': f'Baseline skills match: {len(matched)} of {len(required)} listed skills found. Human review is required.'}
