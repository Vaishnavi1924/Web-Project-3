import {Router} from 'express';
import Job from '../models/Job.js';
const router = Router();
router.get('/', async (_req,res)=>res.json(await Job.find().sort({createdAt:-1})));
router.post('/', async (req,res)=>{
  const {title,description} = req.body;
  if (!title?.trim() || !description?.trim()) return res.status(400).json({message:'Job title and description are required.'});
  const job = await Job.create({...req.body, requiredSkills:Array.isArray(req.body.requiredSkills)?req.body.requiredSkills:String(req.body.requiredSkills||'').split(',').map(s=>s.trim()).filter(Boolean)});
  res.status(201).json(job);
});
router.get('/:id', async (req,res)=>{const job=await Job.findById(req.params.id); if(!job)return res.status(404).json({message:'Job not found'}); res.json(job);});
router.patch('/:id', async (req,res)=>{const job=await Job.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true}); if(!job)return res.status(404).json({message:'Job not found'}); res.json(job);});
router.delete('/:id', async (req,res)=>{const job=await Job.findByIdAndDelete(req.params.id); if(!job)return res.status(404).json({message:'Job not found'}); res.json({message:'Job deleted'});});
export default router;
