import {Router} from 'express';
import fs from 'node:fs/promises';
import Application from '../models/Application.js';
import Job from '../models/Job.js';
import {resumeUpload} from '../middleware/upload.js';
import {extractPdfText,extractSkills} from '../services/resume.js';
import {scoreCandidate} from '../services/matching.js';
import {storeResume} from '../services/storage.js';
const router = Router();
router.get('/', async (req,res)=>{
  const filter = req.query.jobId ? {job:req.query.jobId} : {};
  const apps = await Application.find(filter).populate('job','title department').sort({matchScore:-1,createdAt:-1});
  res.json(apps);
});
router.post('/', (req,res,next)=>resumeUpload.single('resume')(req,res,err=>err?next(err):next()), async (req,res)=>{
  if(!req.file) return res.status(400).json({message:'Please attach a PDF resume.'});
  const {jobId,candidateName,email}=req.body;
  if(!jobId || !candidateName?.trim() || !email?.trim()) {await fs.unlink(req.file.path).catch(()=>{}); return res.status(400).json({message:'jobId, candidateName, and email are required.'});}
  const job=await Job.findById(jobId);
  if(!job || job.status!=='Open') {await fs.unlink(req.file.path).catch(()=>{}); return res.status(404).json({message:'Open job not found.'});}
  try {
    const resumeText=await extractPdfText(req.file.path);
    const extractedSkills=extractSkills(resumeText,job.requiredSkills);
    const score=await scoreCandidate({resumeText,extractedSkills,job});
    const stored=await storeResume(req.file);
    const application=await Application.create({job:job._id,candidateName,email,resumeText,extractedSkills,...score,resumeStorageKey:stored.key,resumeOriginalName:req.file.originalname});
    if(stored.isS3) await fs.unlink(req.file.path).catch(()=>{});
    res.status(201).json(application);
  } catch(error) {
    if(error.code==='11000') return res.status(409).json({message:'This email has already applied to this job.'});
    throw error;
  }
});
router.patch('/:id/status',async(req,res)=>{
  const allowed=['New','Reviewed','Shortlisted','Interview','Rejected','Hired'];
  if(!allowed.includes(req.body.status))return res.status(400).json({message:`Status must be one of: ${allowed.join(', ')}`});
  const app=await Application.findByIdAndUpdate(req.params.id,{status:req.body.status},{new:true}).populate('job','title');
  if(!app)return res.status(404).json({message:'Application not found'}); res.json(app);
});
router.post('/:id/reanalyze',async(req,res)=>{
  const app=await Application.findById(req.params.id); if(!app)return res.status(404).json({message:'Application not found'});
  const job=await Job.findById(app.job); if(!job)return res.status(404).json({message:'Job not found'});
  const extractedSkills=extractSkills(app.resumeText,job.requiredSkills);
  const score=await scoreCandidate({resumeText:app.resumeText,extractedSkills,job});
  Object.assign(app,{extractedSkills,...score}); await app.save(); res.json(app);
});
export default router;
