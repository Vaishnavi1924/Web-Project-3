import mongoose from 'mongoose';
const jobSchema = new mongoose.Schema({
  title: {type:String, required:true, trim:true},
  department: {type:String, default:'General'},
  location: {type:String, default:'Remote'},
  employmentType: {type:String, enum:['Full-time','Part-time','Contract','Internship'], default:'Full-time'},
  description: {type:String, required:true},
  requiredSkills: [{type:String, trim:true}],
  experienceLevel: {type:String, default:'Entry-level'},
  status: {type:String, enum:['Open','Closed'], default:'Open'}
}, {timestamps:true});
export default mongoose.model('Job', jobSchema);
