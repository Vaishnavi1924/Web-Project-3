import mongoose from 'mongoose';
const applicationSchema = new mongoose.Schema({
  job: {type:mongoose.Schema.Types.ObjectId, ref:'Job', required:true, index:true},
  candidateName: {type:String, required:true, trim:true},
  email: {type:String, required:true, trim:true, lowercase:true},
  resumeText: {type:String, default:''},
  extractedSkills: [{type:String}],
  matchedSkills: [{type:String}],
  missingSkills: [{type:String}],
  matchScore: {type:Number, min:0, max:100, default:0},
  matchExplanation: {type:String, default:'Awaiting analysis'},
  resumeStorageKey: {type:String, default:''},
  resumeOriginalName: {type:String, default:''},
  status: {type:String, enum:['New','Reviewed','Shortlisted','Interview','Rejected','Hired'], default:'New'}
}, {timestamps:true});
applicationSchema.index({job:1, email:1}, {unique:true});
export default mongoose.model('Application', applicationSchema);
