import OpenAI from 'openai';
const normalize = s => String(s || '').toLowerCase().trim();
export async function scoreCandidate({resumeText, extractedSkills, job}) {
  const required = [...new Set([...(job.requiredSkills || []), ...extractDescriptionSkills(job.description)])];
  const resumeSkills = new Set(extractedSkills.map(normalize));
  const matchedSkills = required.filter(s => resumeSkills.has(normalize(s)) || resumeText.toLowerCase().includes(normalize(s)));
  const missingSkills = required.filter(s => !matchedSkills.includes(s));
  const baseline = required.length ? Math.round((matchedSkills.length / required.length) * 100) : 0;
  let matchScore = baseline;
  let matchExplanation = `Baseline skills match: ${matchedSkills.length} of ${required.length} job-related skills found. Review the resume and evidence before making a decision.`;
  if (process.env.AI_SERVICE_URL) {
    try {
      const response = await fetch(`${process.env.AI_SERVICE_URL.replace(/\/$/, '')}/analyze`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({resume_text:resumeText.slice(0,100000), job_description:job.description.slice(0,30000), required_skills:job.requiredSkills || []}), signal:AbortSignal.timeout(2500)});
      if (response.ok) { const data = await response.json(); if (Number.isFinite(Number(data.matchScore))) matchScore = Math.max(0,Math.min(100,Math.round(Number(data.matchScore)))); if (Array.isArray(data.matchedSkills)) matchedSkills.splice(0,matchedSkills.length,...data.matchedSkills); if (Array.isArray(data.missingSkills)) missingSkills.splice(0,missingSkills.length,...data.missingSkills); if (data.explanation) matchExplanation = data.explanation; }
    } catch (error) { console.warn('Python AI service unavailable; using local baseline:', error.message); }
  }
  if (process.env.AI_PROVIDER === 'openai' && process.env.OPENAI_API_KEY) {
    try {
      const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
      const response = await client.chat.completions.create({
        model:process.env.OPENAI_MODEL || 'gpt-4o-mini', temperature:0,
        response_format:{type:'json_object'},
        messages:[{role:'system',content:'You assist a recruiter by comparing resume evidence only against job-related requirements. Do not infer or score age, gender, ethnicity, disability, religion, nationality, photo, or other protected/personal traits. Return JSON with score (integer 0-100), matchedSkills (string array), missingSkills (string array), explanation (short string). Do not make a hiring decision.'},
          {role:'user',content:JSON.stringify({jobTitle:job.title, jobDescription:job.description, requiredSkills:required, resumeText:resumeText.slice(0,14000)})}]
      });
      const data = JSON.parse(response.choices[0].message.content || '{}');
      if (Number.isFinite(Number(data.score))) matchScore = Math.max(0,Math.min(100,Math.round(Number(data.score))));
      if (Array.isArray(data.matchedSkills)) matchedSkills.splice(0,matchedSkills.length,...data.matchedSkills.map(String));
      if (Array.isArray(data.missingSkills)) missingSkills.splice(0,missingSkills.length,...data.missingSkills.map(String));
      if (data.explanation) matchExplanation = String(data.explanation);
    } catch (error) { console.error('AI provider failed; using baseline score:', error.message); }
  }
  return {matchScore, matchedSkills, missingSkills, matchExplanation};
}
function extractDescriptionSkills(description='') {
  const catalog = ['javascript','typescript','react','node.js','express','mongodb','sql','python','java','html','css','rest api','git','aws','docker','machine learning','data analysis','pandas','numpy','communication','testing','jest','redux','material ui','fastapi'];
  const d = description.toLowerCase();
  return catalog.filter(skill => d.includes(skill));
}
