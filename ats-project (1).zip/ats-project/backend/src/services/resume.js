import fs from 'node:fs/promises';
import pdf from 'pdf-parse';
const SKILL_TERMS = ['javascript','typescript','react','node.js','express','mongodb','sql','python','java','html','css','rest api','git','aws','docker','machine learning','data analysis','pandas','numpy','communication','testing','jest','redux','material ui','fastapi'];
export async function extractPdfText(filePath) {
  const buffer = await fs.readFile(filePath);
  const parsed = await pdf(buffer);
  const text = (parsed.text || '').replace(/\s+/g,' ').trim();
  if (!text) throw new Error('No selectable text found in PDF. If this is a scanned image, OCR is needed.');
  return text.slice(0, 100000);
}
export function extractSkills(text, additional = []) {
  const lower = text.toLowerCase();
  const terms = [...new Set([...SKILL_TERMS, ...additional.map(s => String(s).toLowerCase())])];
  return terms.filter(skill => new RegExp(`(^|[^a-z0-9+#.])${escapeRegex(skill)}($|[^a-z0-9+#.])`, 'i').test(lower));
}
function escapeRegex(value) { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
