import {S3Client, PutObjectCommand} from '@aws-sdk/client-s3';
import fs from 'node:fs/promises';
import path from 'node:path';
const hasS3 = () => Boolean(process.env.S3_BUCKET && process.env.AWS_REGION);
export async function storeResume(file) {
  if (hasS3()) {
    const client = new S3Client({region:process.env.AWS_REGION});
    const key = `resumes/${Date.now()}-${path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g,'_')}`;
    await client.send(new PutObjectCommand({Bucket:process.env.S3_BUCKET, Key:key, Body:await fs.readFile(file.path), ContentType:'application/pdf', ServerSideEncryption:'AES256'}));
    return {key, isS3:true};
  }
  return {key:file.filename, isS3:false};
}
