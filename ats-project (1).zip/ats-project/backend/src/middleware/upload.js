import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
const uploadDir = path.resolve('uploads');
fs.mkdirSync(uploadDir,{recursive:true});
const storage = multer.diskStorage({destination:uploadDir, filename:(_req,file,cb)=>cb(null,`${Date.now()}-${Math.round(Math.random()*1e9)}${path.extname(file.originalname).toLowerCase()}`)});
const maxMb = Number(process.env.MAX_RESUME_MB || 5);
export const resumeUpload = multer({storage, limits:{fileSize:maxMb*1024*1024, files:1}, fileFilter:(_req,file,cb)=>{
  const validExt = path.extname(file.originalname).toLowerCase() === '.pdf';
  const validMime = file.mimetype === 'application/pdf';
  cb(validExt && validMime ? null : new Error('Only PDF resumes are allowed.'), validExt && validMime);
}});
