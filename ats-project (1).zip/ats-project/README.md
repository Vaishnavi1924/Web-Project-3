# AI-Powered Applicant Tracking System (ATS)

A learning-project implementation covering React, React Query, Material UI, Node.js, Express, MongoDB, Python/FastAPI text processing, PDF resume parsing, Multer uploads, optional OpenAI/Gemini matching, and optional AWS S3 storage.

## Architecture
- `frontend`: React + Vite + React Query + MUI
- `backend`: Express REST API, MongoDB/Mongoose, Multer, PDF parsing, optional AI and S3
- `ai-service`: Python FastAPI microservice for text normalization and transparent baseline scoring

## Prerequisites
- Node.js 20+ and npm
- Python 3.10+
- MongoDB local installation or MongoDB Atlas database
- Optional: OpenAI or Gemini API key
- Optional: AWS S3 bucket and credentials

## 1. Configure backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Edit `.env` and set `MONGODB_URI`. Server defaults to `http://localhost:5000`.

## 2. Configure Python service (recommended)
In a second terminal:
```bash
cd ai-service
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
The Node API uses `AI_SERVICE_URL=http://localhost:8000` when the service is available. Its transparent baseline score is a helper, not a hiring decision.

## 3. Start frontend
In a third terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL printed in the terminal (usually `http://localhost:5173`).

## 4. Use the application
1. Create a job from the Jobs page.
2. Open the job's Apply link or use the Applications page to upload a PDF resume with a candidate name and email.
3. The backend extracts PDF text, extracts likely skills, saves the application, and calculates a job-related match score.
4. View the application ranking and update application status from the dashboard.

## API endpoints
- `GET /api/health`
- `GET /api/jobs`
- `POST /api/jobs`
- `GET /api/jobs/:id`
- `PATCH /api/jobs/:id`
- `DELETE /api/jobs/:id`
- `GET /api/applications?jobId=<id>`
- `POST /api/applications` (multipart form: `resume`, `jobId`, `candidateName`, `email`)
- `PATCH /api/applications/:id/status`
- `POST /api/applications/:id/reanalyze`

## AI provider settings
Set `AI_PROVIDER=none`, `openai`, or `gemini` in backend `.env`. The baseline matcher works without an external AI key. For OpenAI set `OPENAI_API_KEY` and optionally `OPENAI_MODEL`. For Gemini set `GEMINI_API_KEY` and optionally `GEMINI_MODEL`. AI output is advisory and should be reviewed by a human.

## AWS S3 settings (optional)
Set `S3_BUCKET`, `AWS_REGION`, `AWS_ACCESS_KEY_ID`, and `AWS_SECRET_ACCESS_KEY`. If no bucket is configured, the development version stores uploaded PDFs in `backend/uploads`. Never expose a public bucket or commit credentials. For production, use private objects and short-lived presigned URLs, malware scanning, upload limits, retention rules, and access controls.

## Security and production checklist
This scaffold is intended for learning and local development. Before real use, add authentication and role-based authorization (recruiter/admin/candidate), rate limiting, CSRF protections where applicable, audit logging, secure session/token handling, file malware scanning, data retention/deletion controls, encryption, input validation, consent notices, and privacy/legal review. Do not use protected characteristics or proxies as ranking inputs. Keep hiring decisions under human control.
