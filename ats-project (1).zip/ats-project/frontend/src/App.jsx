import {useState} from 'react';
import {Routes,Route,NavLink,useLocation} from 'react-router-dom';
import {AppBar,Toolbar,Typography,Button,Container,Stack,Box} from '@mui/material';
import WorkOutlineIcon from '@mui/icons-material/WorkOutline';
import Dashboard from './pages/Dashboard.jsx';
import Jobs from './pages/Jobs.jsx';
import Applications from './pages/Applications.jsx';
import Apply from './pages/Apply.jsx';
export default function App(){
 const location=useLocation();
 return <Box minHeight="100vh"><AppBar position="static" elevation={0}><Toolbar sx={{gap:2,flexWrap:'wrap'}}><WorkOutlineIcon/><Typography variant="h6" sx={{flexGrow:1,fontWeight:800}}>TalentAI · ATS</Typography><Stack direction="row" spacing={1}><Button color="inherit" component={NavLink} to="/" sx={{textDecoration:'none'}}>Dashboard</Button><Button color="inherit" component={NavLink} to="/jobs">Jobs</Button><Button color="inherit" component={NavLink} to="/applications">Applications</Button></Stack></Toolbar></AppBar><Container maxWidth="xl" sx={{py:4}}><Routes><Route path="/" element={<Dashboard/>}/><Route path="/jobs" element={<Jobs/>}/><Route path="/applications" element={<Applications/>}/><Route path="/apply/:jobId" element={<Apply/>}/><Route path="*" element={<Typography>Page not found</Typography>}/></Routes><Typography color="text.secondary" variant="caption" display="block" textAlign="center" sx={{mt:6}}>AI recommendations are advisory. Recruiters must review job-related evidence and make final decisions.</Typography></Container></Box>
}
