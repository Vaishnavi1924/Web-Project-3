import axios from 'axios';
export const api = axios.create({baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api'});
export const getJobs = async () => (await api.get('/jobs')).data;
export const createJob = async payload => (await api.post('/jobs',payload)).data;
export const getApplications = async jobId => (await api.get('/applications',{params:jobId?{jobId}:{}})).data;
export const createApplication = async formData => (await api.post('/applications',formData,{headers:{'Content-Type':'multipart/form-data'}})).data;
export const updateStatus = async ({id,status}) => (await api.patch(`/applications/${id}/status`,{status})).data;
