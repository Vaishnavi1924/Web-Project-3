import {useQuery} from '@tanstack/react-query';
import {getJobs,getApplications} from '../api/client.js';
import {Alert,Card,CardContent,Grid,Typography,Stack,Button} from '@mui/material';
import {Link} from 'react-router-dom';
export default function Dashboard(){
 const jobs=useQuery({queryKey:['jobs'],queryFn:getJobs}); const apps=useQuery({queryKey:['applications'],queryFn:()=>getApplications()});
 if(jobs.isError||apps.isError)return <Alert severity="error">Could not load dashboard. Check that the backend and MongoDB are running.</Alert>;
 const shortlist=(apps.data||[]).filter(a=>a.status==='Shortlisted').length;
 const metrics=[['Open jobs',(jobs.data||[]).filter(j=>j.status==='Open').length],['Applications',(apps.data||[]).length],['Shortlisted',shortlist]];
 return <Stack spacing={3}><div><Typography variant="h4" fontWeight={800}>Recruitment dashboard</Typography><Typography color="text.secondary">Track open roles, incoming applications, and job-related matching scores.</Typography></div><Grid container spacing={2}>{metrics.map(([label,value])=><Grid item xs={12} sm={4} key={label}><Card><CardContent><Typography color="text.secondary">{label}</Typography><Typography variant="h3" fontWeight={800}>{value??'—'}</Typography></CardContent></Card></Grid>)}</Grid><Card><CardContent><Typography variant="h6" fontWeight={700}>Get started</Typography><Typography sx={{my:1}}>Create a job, then upload candidate PDF resumes to compare job-related skills.</Typography><Stack direction="row" spacing={2}><Button variant="contained" component={Link} to="/jobs">Manage jobs</Button><Button variant="outlined" component={Link} to="/applications">Review applications</Button></Stack></CardContent></Card></Stack>
}
