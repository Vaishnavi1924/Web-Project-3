import React from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter} from 'react-router-dom';
import {QueryClient,QueryClientProvider} from '@tanstack/react-query';
import {CssBaseline,ThemeProvider,createTheme} from '@mui/material';
import App from './App.jsx';
const queryClient=new QueryClient({defaultOptions:{queries:{staleTime:15000,retry:1}}});
const theme=createTheme({palette:{mode:'light',primary:{main:'#3949ab'},background:{default:'#f5f7fb'}},shape:{borderRadius:10},typography:{fontFamily:'Inter, Roboto, Arial, sans-serif'}});
createRoot(document.getElementById('root')).render(<React.StrictMode><QueryClientProvider client={queryClient}><ThemeProvider theme={theme}><CssBaseline/><BrowserRouter><App/></BrowserRouter></ThemeProvider></QueryClientProvider></React.StrictMode>);
